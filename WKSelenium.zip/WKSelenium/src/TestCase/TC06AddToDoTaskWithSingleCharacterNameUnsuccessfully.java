package TestCase;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

public class TC06AddToDoTaskWithSingleCharacterNameUnsuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    void singlechartask() {
        // Add the task
        driver.findElement(By.id("todo-input")).sendKeys("X",Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // Verify task has not been added
        try {
            // Attempt to find the tasks
            WebElement button = driver.findElement(By.xpath ("//*[contains(text(),'X')]"));
            System.out.println("Test Failed");
        } catch (NoSuchElementException e) {
            System.out.println("Test Passed");
        }

        driver.close();
    }
}