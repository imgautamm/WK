package TestCase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

public class TC03MarkToDoTaskCompletedSuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    void markcompleted() {
        {

            // Add task
            driver.findElement(By.id("todo-input")).sendKeys("Test Plan", Keys.RETURN);
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            // Mark task completed
            driver.findElement(By.xpath("//*[@id=\"root\"]/main/ul/li/div/input")).click();
            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
            // Verify completed tasks visible under completed section
            driver.findElement(By.className("completed")).click();
            driver.findElement(By.xpath("//*[@id=\"root\"]/main/ul/li/div/label"));

            try {
                // Attempt to find the completed tasks
                WebElement button = driver.findElement(By.xpath("//*[@id=\"root\"]/main/ul/li/div/label"));
                System.out.println("Test Passed");
            } catch (NoSuchElementException e) {
                System.out.println("Test Failed");
            }
            driver.close();
        }
    }
}