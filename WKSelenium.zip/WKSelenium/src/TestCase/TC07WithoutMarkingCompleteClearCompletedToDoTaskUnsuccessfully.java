package TestCase;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

@Test
public class TC07WithoutMarkingCompleteClearCompletedToDoTaskUnsuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    void clearwithoutmarkinhg() {
        // Add task
        driver.findElement(By.id("todo-input")).sendKeys("Test Plan", Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // clear all the completed tasks
        driver.findElement(By.className("clear-completed")).click();
        try {
            // Attempt to find the cleared tasks
            WebElement button = driver.findElement(By.xpath("//*[contains(text(),'Test Plan')]"));
            System.out.println("Test Passed");

        } catch (NoSuchElementException e) {
            System.out.println("Test Failed");
        }
        driver.close();
    }
}
