package TestCase;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;


public class TC08CompletedToDoTaskComesUnderActiveSectionUnsuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    void nocompletedtaskinactive() {
        // Add task
        driver.findElement(By.id("todo-input")).sendKeys("1-Test Plan", Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // Mark task completed
        driver.findElement(By.xpath("//*[@id=\"root\"]/main/ul/li/div/input")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // Verify completed tasks not visible under Active section
        driver.findElement(By.xpath("//*[@id=\"root\"]/footer/ul/li[2]/a")).click();

        try {
            // Attempt to find the completed tasks under Active section
            WebElement button = driver.findElement(By.xpath("//*[contains(text(),'1-Test Plan')]"));
            System.out.println("Test Failed");
        } catch (NoSuchElementException e) {
            System.out.println("Test Passed");
        }
        driver.close();
    }
}
