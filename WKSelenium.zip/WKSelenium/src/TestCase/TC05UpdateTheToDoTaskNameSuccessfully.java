package TestCase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class TC05UpdateTheToDoTaskNameSuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    public void updatetodotask() {
        // Create new task
        driver.findElement(By.id("todo-input")).sendKeys("Test Plan", Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        // verify task is created
        driver.findElement(By.xpath("//*[contains(text(),'Test Plan')]"));
        // Find the initial element that triggers the text box to appear
        WebElement triggerElement = driver.findElement(By.xpath("//*[contains(text(),'Test Plan')]"));

        // Instantiate Actions class
        Actions actions = new Actions(driver);

        try {
            // Double click on the text box
            actions.doubleClick(triggerElement).perform();

            // Find the text box element
            WebElement textBox = driver.findElement(By.xpath("//*[@id=\"root\"]/main/ul/li/div/div"));
            Thread.sleep(2000);

            // Clear the existing text in the text box and enter new text
            textBox.clear();
            //Static wait for 2 seconds
            Thread.sleep(2000);
            textBox.sendKeys("Test Design");
            System.out.println("Test Passed");
            //String actualStatus = "Test Passed";
        } catch (Exception e) {
            System.out.println("Test Failed");
            driver.close();
            Assert.fail("Test Failed: Exception occurred - " + e.getMessage());
        }
    }
}
