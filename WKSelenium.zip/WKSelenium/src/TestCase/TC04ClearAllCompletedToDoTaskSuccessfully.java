package TestCase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;


public class TC04ClearAllCompletedToDoTaskSuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    void clearallcompleted() {
        // Add tasks
        driver.findElement(By.id("todo-input")).sendKeys("1-Test Plan", Keys.RETURN);
        driver.findElement(By.id("todo-input")).sendKeys("2-Test Design", Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // Select and mark all task completed
        driver.findElement(By.xpath("//*[@id=\"root\"]/main/div/input")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // verify tasks are completed
        driver.findElement(By.className("completed")).click();
        // clear all the completed tasks
        driver.findElement(By.className("clear-completed")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // verify no completed tasks exists
        try {
            // Attempt to find the uncleared tasks
            WebElement button = driver.findElement(By.xpath("//*[contains(text(),'1-Test Plan')]"));
            System.out.println("Test Failed");
        } catch (NoSuchElementException e) {
            System.out.println("Test Passed");
        }

        driver.close();
    }
}
