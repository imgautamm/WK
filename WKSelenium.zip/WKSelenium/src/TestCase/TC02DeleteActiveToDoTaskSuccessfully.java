package TestCase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

public class TC02DeleteActiveToDoTaskSuccessfully {
    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }

    @Test
    void deleteactivetask() {

        // Add new task
        driver.findElement(By.id("todo-input")).sendKeys("Test Plan", Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        try {
            // Locate the element to hover over
            WebElement elementToHover = driver.findElement(By.xpath("//*[contains(text(),'Test Plan')]"));

            // Instantiate Actions class
            Actions actions = new Actions(driver);

            // Perform hover action on the element
            actions.moveToElement(elementToHover).perform();

            // After hovering, locate and click the button that appears
            WebElement buttonToClick = driver.findElement(By.className("destroy"));
            buttonToClick.click();

            System.out.println("Test Passed");
            //Static wait for 2 seconds
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Test Failed");
        }

        driver.close();
    }
}