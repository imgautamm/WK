package TestCase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TC01CreateToDoTaskSuccessfully {

    WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver",
                "/Users/gautam/Downloads/Selenium/chromedriver-mac-x64/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://todomvc.com/examples/react/dist/");
    }
    @Test
    void createtodotask() {
        // Add the task
        driver.findElement(By.id("todo-input")).sendKeys("Test Plan",Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        // Verify task has been added
        String taskname = driver.findElement(By.xpath ("//*[contains(text(),'Test Plan')]")).getText();
        /*
         * If actual Task name matches with expected one print
         * the result as "Passed" or "Failed"
         */
        if (taskname.contentEquals("Test Plan"))
        {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed!");
        }
        driver.close();
    }
}